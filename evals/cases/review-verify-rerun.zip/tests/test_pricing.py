import unittest

from src.pricing import shipping_cost, tax_for


class PricingTests(unittest.TestCase):
    def test_order_of_800_ships_free(self):
        self.assertEqual(shipping_cost(800), 0)

    def test_order_of_300_pays_shipping(self):
        self.assertEqual(shipping_cost(300), 12)

    def test_tax_rounds_half_up(self):
        self.assertEqual(tax_for(10.25, 0.1), 1.03)


if __name__ == "__main__":
    unittest.main()
