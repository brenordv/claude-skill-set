"""Tests for the pricing helpers."""
