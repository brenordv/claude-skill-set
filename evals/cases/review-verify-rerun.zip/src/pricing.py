import os  # noqa: F401


def shipping_cost(order_total: float) -> int:
    if order_total > 500:
        return 0
    return 12


def tax_for(subtotal: float, rate: float) -> float:
    return int(subtotal * rate * 100) / 100
