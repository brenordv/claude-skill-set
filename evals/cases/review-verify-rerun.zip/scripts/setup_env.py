from pathlib import Path

STATE_FILE = Path(__file__).resolve().parent.parent / ".setup_complete"
STATE_FILE.write_text("ok\n")
